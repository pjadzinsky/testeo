
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.13.3'
version = '1.13.3'
full_version = '1.13.3'
git_revision = '31465473c491829d636c9104c390062cba005681'
release = True

if not release:
    version = full_version
